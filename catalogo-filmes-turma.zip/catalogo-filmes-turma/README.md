# Banco de dados

## Aula 1

Criação do banco de dados, tabela filme e classe Model para lidar com a tabela filme no PHP.

Filme
 id
 nome
 ano
 descricao


Exercicios

- Instruções para inserir ao menos 20 registros
- Instrução para retornar todos os registros
- Instrução para retornar um unico registro por id
- Instrução para retornar apenas nome e ano de todos
- Instrução para atualizar um registro por id
- Instrução para excluir um registro por id
- Criar a tabela
Usuario
 id
 nome
 email

Favorito
 usuario_id
 filme_id

## Aula 2

Criado 2 métodos de consulta no Filme model e criação da listagem de filmes.

## Aula 3

Organizando a estrura do projeto.
Criação da funcionalidade de ver detalhes do filme.

Fazer a listagem e visualização do usuário.

## Aula 4

Criar a funcionalidade de excluir Filme
Criar a funcionalidade de excluir Usuario

# Aula 5

Funcionalidade de notificação de sucesso ou erro ao excluir Filme

---

