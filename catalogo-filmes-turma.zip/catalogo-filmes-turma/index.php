<?php

return header("Location: app/View/Filme/Listar.php");

?>